package es.ies.puerto.list;

/**
 * @author nexphernandez
 * @version 1.0.0
 */
import java.util.ArrayList;
import java.util.List;

import es.ies.puerto.Persona;

public class PersonaList {

    private List<Persona> personas;

    /**
     * Constructor por defecto
     */
    public PersonaList() {
        this.personas = new ArrayList<>();
    }

    /**
     * Funcion para agregar personas a la lista
     * @param persona a agregar
     * @return true/false
     */
    public boolean agregar(Persona persona) {
        if (!personas.contains(persona)) {
            return personas.add(persona);
        } else {
            return false;
        }
    }

    /**
     * Funcion para listar los animales
     * @return animales en la lista
     */
    public List<Persona> listar() {
        return new ArrayList<>(personas);
    }

    /**
     * Funcion para buscar los animales de una lista
     * @param dni de la persona a buscar
     * @return persona a buscar
     */
    public Persona buscar(String dni) {
        Persona personaBuscar = new Persona(dni);
        int posicion = personas.indexOf(personaBuscar);
        if (posicion < 0) {
            return null;
        } else {
            return personas.get(posicion);
        }
        /**
        return personas.stream()
                .filter(p -> p.getDni().equals(dni))
                .findFirst()
                .orElse(null);
            */     
    }

    /**
     * Funcion para actualizar los datos de una persona de la lista
     * @param dni de la persona a actualizar
     * @param nuevaPersona con los datos actualizados
     * @return true/false.
     */
    public boolean actualizar(String dni, Persona nuevaPersona) {
        /**
        for (int i = 0; i < personas.size(); i++) {
            if (personas.get(i).getDni().equals(dni)) {
                personas.set(i, nuevaPersona);
                return;
            }
        }
        */
        Persona personaBuscar = new Persona(dni);
        int posicion = personas.indexOf(personaBuscar);
        if (posicion < 0) {
            return false;
        }
        personas.set(posicion, nuevaPersona);
        return true;
    }

    /**
     * Funcion para eliminar una persona de la lista
     * @param dni de la persona
     * @return true/false
     */
    public boolean eliminar(String dni) {
        Persona personaEliminar = new Persona(dni);
        return personas.remove(personaEliminar);
    }
    
}
