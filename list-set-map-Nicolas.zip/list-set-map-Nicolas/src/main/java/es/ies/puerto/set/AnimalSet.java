package es.ies.puerto.set;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import es.ies.puerto.*;

public class AnimalSet {
    private Set<Animal> animales;

    public AnimalSet() {

    }

    public boolean agregar(Animal animal) {
        return false;
    }

    public Set<Animal> listarAnimales() {
        return new HashSet();
    }

    public Animal buscar(String identificador) {
        return null;     
    }

    public boolean actualizar(String identificador, Animal nuevoAnimal) {
        return false;
    }

    public boolean eliminar(String identificador) {
        return false;
    }

}
