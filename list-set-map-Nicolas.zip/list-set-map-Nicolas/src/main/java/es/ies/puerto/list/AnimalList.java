package es.ies.puerto.list;

/**
 * @author nexphernandez
 * @version 1.0.0
 */
import java.util.ArrayList;
import java.util.List;

import es.ies.puerto.*;

public class AnimalList {
    private List<Animal> animales;

    /**
     * Contructor vacío.
     */
    public AnimalList() {
        this.animales = new ArrayList<>();
    }

    /**
     * funcion para agregar animales a la lista
     * @param animal a agregar
     * @return true/false
     */
    public boolean agregar(Animal animal) {
        if (!animales.contains(animal)) {
            return animales.add(animal);
        } else{
            return false;
        }
    }

    /**
     * Funcion para listar los animales
     * @return lista completa de animales
     */
    public List<Animal> listar() {
        return new ArrayList<>(animales);
    }

    /**
     * Funcion para buscar animales de una lista
     * @param identificador del animal
     * @return animal buscado
     */
    public Animal buscar(String identificador) {
        Animal animalBuscar = new Animal(identificador);
        int posicion = animales.indexOf(animalBuscar);
        if (posicion < 0) {
            return null;
        }
        return animales.get(posicion);     
    }

    /**
     * Funcion para actualizar los datos de los animales
     * @param identificador del animal
     * @param nuevoAnimal con los datos actualizados
     * @return true/false
     */
    public boolean actualizar(String identificador, Animal nuevoAnimal) {
        Animal animalBuscar = new Animal(identificador);
        int posicion = animales.indexOf(nuevoAnimal);
        if (posicion < 0) {
            return false;
        }
        animales.set(posicion, animalBuscar);
        return true;
    }

    /**
     * Funcion para  eliminar un animal de la lista
     * @param identificador del animal
     * @return true/false
     */
    public boolean eliminar(String identificador) {
        Animal animalEliminar = new Animal(identificador);
        return animales.remove(animalEliminar);
    }

}
