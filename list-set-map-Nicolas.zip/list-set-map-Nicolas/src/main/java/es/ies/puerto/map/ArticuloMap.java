package es.ies.puerto.map;
/**
 * @author nexphernandez
 * @version 1.0.0
 */

import java.util.HashMap;
import java.util.Map;

import es.ies.puerto.Articulo;

public class ArticuloMap {
    Map<String, Articulo> articulos;

    /**
     * Contructor de vacio
     */
    public ArticuloMap() {
        this.articulos = new HashMap<>();
    }

    /**
     * Funcion para agregar articulos al mapa
     * @param articulo a agregar en la lista
     * @return true/false
     */
    public boolean agregar(Articulo articulo) {
        if (articulo == null) {
            return false;
        }
        if (articulos.containsValue(articulo)) {
            return false;
        }
        articulos.put(articulo.getCodigo(), articulo);
        return true;
    }

    /**
     * Funcion para listar los articulos del mapa
     * @return articulos del mapa listados
     */
    public Map<String, Articulo> listar() {
        return new HashMap(articulos);
    }

    /**
     * Funcion para buscar un articulo en el mapa
     * @param codigo del articulo
     * @return true false
     */
    public Articulo buscar(String codigo) {

        return null;     
    }

    public boolean actualizar(String codigo, Articulo nuevoArticulo) {
        return false;
    }

    public boolean eliminar(String codigo) {
        return false;
    }
}
